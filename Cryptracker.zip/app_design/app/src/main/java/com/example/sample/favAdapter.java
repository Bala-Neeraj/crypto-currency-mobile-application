package com.example.sample;

///public class favAdapter extends RecyclerView.Adapter<favAdapter.ViewHolder> {
//
//    private ArrayList<favitem> favitems;
  //  private Context context;
 //   private fav fav;

  //  public favAdapter(ArrayList<favitem> favitems,Context context){
  //      this.context=context;
  //      this.favitems=favitems;
  //  }
  //  public void filterList(ArrayList<favitem> filterllist) {
        // adding filtered list to our
        // array list and notifying data set changed
        //favitems = filterllist;
    //    notifyDataSetChanged();

 //   }
  //  @NonNull
  //  @Override
   // public favAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//
  //      View view = LayoutInflater.from(context).inflate(R.layout.currency_rv_item, parent, false);
  //      return new favAdapter.ViewHolder(view);
  //  }

  //  private void createTableOnFirstStart() {

 //   }

 ////   @Override
  //  public void onBindViewHolder(@NonNull favAdapter.ViewHolder holder, int position) {
  //      favitem modal = favitems.get(position);
   //     holder..setText(modal.getName());
   //     holder.rateTV.setText("$ " + df2.format(modal.getPrice()));
   //     holder.symbolTV.setText(modal.getSymbol());--!>


    //}

  //  @Override
  //  public int getItemCount() {
 //       return 0;
  //  }
//

  //  public class ViewHolder extends RecyclerView.ViewHolder{
   //     public ViewHolder(@NonNull View itemView){
       ////     super(itemView);
  //      }
 //   }//
//}
